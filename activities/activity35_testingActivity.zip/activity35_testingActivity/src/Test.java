public class Test {
    public static void main(String[] args) {
        Student test = new Student("Hog Tied", 7, "math");
        System.out.println("Student name: " + test.getName());
    }
}
