public class testBigO {
    public static void main(String[] args) {
        BigO big = new BigO();
        big.printOnce(3);
        big.printNTimes(4);
        big.printNSquaredTimes(3);
    }
}
