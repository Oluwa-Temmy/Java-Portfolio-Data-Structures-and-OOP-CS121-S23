//*********************************************************
//         Activity 28: Date Format
//          Submission: 4/24/2023
//******************************************************
//Description: This program uses the add students to a Set
//and then displays the students.
//********************************************************

public class Main {
    public static void main(String[] args) {
        StudentSet test = new StudentSet();
        test.addStudents();
        test.displayStudent();
    }


}
