public class Members {
    String name;
    int dob;
    String line;

    Members (String name, int dob, String line){
        this.name = name;
        this.dob = dob;
        this.line = line;
    }


}
