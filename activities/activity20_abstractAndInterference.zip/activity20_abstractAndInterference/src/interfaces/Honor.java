package interfaces;

public interface Honor {
    String isHonors();
}
