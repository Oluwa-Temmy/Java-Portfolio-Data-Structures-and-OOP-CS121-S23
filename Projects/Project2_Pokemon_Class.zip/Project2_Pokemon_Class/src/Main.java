public class Main {
    public static void main(String[] args) {
        PokemonSelection game = new PokemonSelection();
        game.assignPokemon();

    }
}
